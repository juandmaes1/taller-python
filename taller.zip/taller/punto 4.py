g = input("ingrese un numero")
x = int(g)
i = input("ingrese un numero")
y = int(i)
Suma = x + y
Diferencia = x -y
Producto = x*y
Cociente = x/y
Residuo = x%y
u = input("ingrese un numero")
m = float(u)
p = input("ingrese un numero")
n = float(p)
Suma2 = n + m
Diferencia2 = n -m
Producto2 = n*m
Cociente2 = n/m
Residuo2 = n % m
Suma3 = x + n
Cociente3 = y/m
Residuo3 = y%m
doble = 2*x, 2*y,2*m, 2*n
sumat = x+y+n+m
productot = x*y*n*m

print("x es igual a ", str(x) , "y es igual a ", str(y),"n es igual a ", str(n) , "m es igual a ", str(m), "")
print("suma, resta , producto , cociente, residuo de x & y ", str(Suma),"  ","  ",str(Diferencia), "  ",(Producto),"  ",str(Cociente),"  ",str(Residuo))
print("suma, resta , producto , cociente, residuo de n & m ", "  ",str(Suma2),"  ",str(Diferencia2), "  ",str(Producto2),"  ",str(Cociente2),"  ",str(Residuo2))
print("suma de todas las variables , producto de todas las variables , cociente de y & m, residuo de y & m, doble de cada variable", "  ",str(Suma3),"  " ,str(productot),"  ",str(Cociente3),"  ",str(Residuo3))








