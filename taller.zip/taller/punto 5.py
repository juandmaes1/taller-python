
g = input("ingrese una velocidad en km/h")
x = float(g)

metross = x / 3.6

print(" su velocidad en m/s ", str(metross))