

g = input("ingrese un precio")
x = float(g)
IVA = x * 0.21
ptotal = x + IVA
print("el precio total es de ", ptotal)