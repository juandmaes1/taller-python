g = input("ingrese el radio del ciruclo")
circ= float(g)
areacirc = 3.14*(circ*circ)
print("area del circulo es " , areacirc)
t = input("ingrese la base del triangulo")
tri = float(t)
u = input("ingrese la altura del trinagulo")
htri = float(u)
areatri = (tri*htri)/2
print("area del trinagulo es " , areatri)
y = input("ingrese el lado del cuadrado")
cua = float(y)
areacu = cua*cua
print("area del cuadrado es " , areacu)