import math

g = input("ingrese un numero")
x = float(g)

resultado = math.radians(x)
print(" en radianes ", resultado)

